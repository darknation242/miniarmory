SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for arena_ladder
-- ----------------------------
DROP TABLE IF EXISTS `arena_ladder`;
CREATE TABLE `arena_ladder` (
  `key` int(100) NOT NULL auto_increment,
  `id` int(100) NOT NULL,
  `realm` int(100) NOT NULL,
  `rank` int(100) NOT NULL,
  PRIMARY KEY  (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin2;
